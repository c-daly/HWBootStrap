using HexWars.Engine;
using System.Text.Json;
using System.Security.Cryptography;

var root=Directory.GetCurrentDirectory();
Directory.CreateDirectory(root+"/replays");
var summary = new List<Outcome>();
using var csv = new StreamWriter(root+"/matches.csv");
csv.WriteLine("id,seed,k,p0,p1,winner,round,commands,attacks,kills,firstAttackSeat,firstAttackRound,firstKillSeat,firstKillRound,maxKillsInTurn,alive0,alive1,terminal,externalCap");
foreach(var (p0,p1) in new[]{("greedy","greedy"),("charge","charge"),("hold","hold"),("charge","hold"),("hold","charge")})
 for(int seed=1;seed<=24;seed++) Run(seed,3,p0,p1);
File.WriteAllText(root+"/summary.json",JsonSerializer.Serialize(summary,new JsonSerializerOptions{WriteIndented=true}));
Console.WriteLine("COMPLETE "+summary.Count);
void Run(int seed,int k,string p0,string p1) {
 var s=New(seed,k);string id=$"k{k}-{p0}-{p1}-seed{seed:D2}";using var replay=new StreamWriter(root+"/replays/"+id+".jsonl");
 var agents=new IAgent[]{Agent(p0,seed*100+17),Agent(p1,seed*100+43)};
 int commands=0,attacks=0,kills=0,firstAS=-1,firstAR=-1,firstKS=-1,firstKR=-1,maxkills=0,turnkills=0;
 replay.WriteLine(JsonSerializer.Serialize(new {kind="initial",id,setup=new GameSetup(GameMode.Annihilation,9,7,0,seed,turnActions:k).ToWire(),state=Snapshot(s)}));
 while(!s.IsGameOver && commands<2500) {
  var cmd=agents[(int)s.ActivePlayer].Decide(s);var next=GameEngine.Apply(s,cmd);if(!next.Success)throw new Exception(id+": "+cmd+" rejected "+next.Reason);
  int dead=s.Players.Sum(p=>p.UnitsOnBoard.Count(u=>u.IsAlive))-next.NewState.Players.Sum(p=>p.UnitsOnBoard.Count(u=>u.IsAlive));dead=Math.Max(0,dead);
  int damage=s.Players.Sum(p=>p.UnitsOnBoard.Where(u=>u.IsAlive).Sum(u=>u.CurrentHp))-next.NewState.Players.Sum(p=>p.UnitsOnBoard.Where(u=>u.IsAlive).Sum(u=>u.CurrentHp));
  if(cmd is AttackUnit){attacks++;if(firstAS<0){firstAS=(int)s.ActivePlayer;firstAR=s.Round;}}
  if(dead>0){kills+=dead;turnkills+=dead;maxkills=Math.Max(maxkills,turnkills);if(firstKS<0){firstKS=(int)s.ActivePlayer;firstKR=s.Round;}}
  replay.WriteLine(JsonSerializer.Serialize(new{step=commands+1,round=s.Round,seat=(int)s.ActivePlayer,command=cmd.ToString(),damage=Math.Max(0,damage),kills=dead,state=Snapshot(next.NewState)}));
  if(next.NewState.ActivePlayer!=s.ActivePlayer)turnkills=0;
  s=next.NewState;commands++;
 }
 var o=new Outcome(id,seed,k,p0,p1,s.Winner==null?-1:(int)s.Winner,s.Round,commands,attacks,kills,firstAS,firstAR,firstKS,firstKR,maxkills,s.Players[0].UnitsOnBoard.Count(u=>u.IsAlive),s.Players[1].UnitsOnBoard.Count(u=>u.IsAlive),s.IsGameOver,!s.IsGameOver);
 summary.Add(o);csv.WriteLine(string.Join(",",o.id,o.seed,o.k,o.p0,o.p1,o.winner,o.round,o.commands,o.attacks,o.kills,o.firstAttackSeat,o.firstAttackRound,o.firstKillSeat,o.firstKillRound,o.maxKillsInTurn,o.alive0,o.alive1,o.terminal,o.externalCap));csv.Flush();
 if(seed%4==0)Console.WriteLine($"{id} winner={o.winner} round={o.round} commands={commands}");
}
static GameState New(int seed,int k)=>GameFactory.Build(new GameSetup(GameMode.Annihilation,9,7,0,seed,turnActions:k));
static IAgent Agent(string name,int seed)=>name=="greedy"?new GreedyAgent(seed):new Tactical(name=="hold",seed);
static object Snapshot(GameState s)=>new{round=s.Round,active=(int)s.ActivePlayer,over=s.IsGameOver,winner=s.Winner?.ToString(),units=s.Players.SelectMany(p=>p.UnitsOnBoard.Where(u=>u.IsAlive).Select(u=>new{id=u.Id,seat=(int)u.Owner,role=u.DisplayName,q=u.Cell.Q,r=u.Cell.R,h=u.Elevation,hp=u.CurrentHp,cost=u.Stats.PointCost})).ToArray(),banks=s.Players.Select(p=>p.Points).ToArray()};
record Outcome(string id,int seed,int k,string p0,string p1,int winner,int round,int commands,int attacks,int kills,int firstAttackSeat,int firstAttackRound,int firstKillSeat,int firstKillRound,int maxKillsInTurn,int alive0,int alive1,bool terminal,bool externalCap);
class Tactical:IAgent {
 readonly double risk,approach;readonly Random rng;
 public Tactical(bool hold,int seed){risk=hold?1.05:0.16;approach=hold?0.08:0.50;rng=new(seed);}
 public Command Decide(GameState s){
  var me=s.ActivePlayer;var opp=s.Opponent(me);var mine=s.Player(me);
  var legal=LegalMoves.For(s);Command best=new EndTurn(me);double bs=0.00001;
  // Threat estimation uses all enemy legal destination cells under refreshed budgets.
  var fresh=new GameState(s.Board,s.Config,s.Players,opp.Id,s.Round,s.NextEntityId);
  var enemyLocations=opp.UnitsOnBoard.Where(u=>u.IsAlive).Select(u=>(u, cells:MovementService.ReachableTiles(fresh,u).Append(u.Cell).ToArray())).ToArray();
  double RiskAt(Unit target){
   int summed=0;
   foreach(var (enemy,cells) in enemyLocations){int strongest=0;foreach(var cell in cells){
    if(cell==target.Cell)continue;var attacker=enemy.WithCell(cell,s.Board.TileAt(cell).Elevation);
    if(!TargetingService.InRange(attacker,target.Cell,target.Elevation,s.Config)||!TargetingService.HasShot(s,attacker,target.Cell,target.Elevation))continue;
    bool sees=(HexCoord.Distance(cell,target.Cell)<=attacker.Stats.Vision && Math.Max(0,target.Elevation-attacker.Elevation)<=attacker.Stats.VisionArc && LineOfSight.IsClear(s.Board,cell,attacker.Elevation,target.Cell,target.Elevation)) || TargetingService.IsVisibleToArmy(s,opp.Id,target.Cell,target.Elevation);
    if(sees)strongest=Math.Max(strongest,CombatResolver.ComputeDamage(attacker.Stats.Damage,attacker.Elevation,target.Elevation,target.Stats.Defense,s.Config));
   }summed+=strongest;}
   return ValueDamage(target,summed);
  }
  double Opportunity(GameState world,Unit u)=>world.AttackedUnitIds.Contains(u.Id)?0:world.Opponent(u.Owner).UnitsOnBoard.Where(t=>t.IsAlive&&TargetingService.CanTarget(world,u,t.Cell,t.Elevation)).Select(t=>ValueDamage(t,CombatResolver.ComputeDamage(u.Stats.Damage,u.Elevation,t.Elevation,t.Stats.Defense,world.Config))).DefaultIfEmpty(0).Max();
  double Dist(Unit u)=>opp.UnitsOnBoard.Where(t=>t.IsAlive).Select(t=>HexCoord.Distance(u.Cell,t.Cell)).DefaultIfEmpty(0).Min();
  var before=mine.UnitsOnBoard.Where(u=>u.IsAlive).ToDictionary(u=>u.Id,u=>(risk:RiskAt(u),op:Opportunity(s,u),dist:Dist(u)));
  foreach(var cmd in legal){double score;
   if(cmd is AttackUnit attack){var a=mine.UnitsOnBoard.First(u=>u.Id==attack.AttackerId);var t=opp.UnitsOnBoard.First(u=>u.Id==attack.TargetId);score=ValueDamage(t,CombatResolver.ComputeDamage(a.Stats.Damage,a.Elevation,t.Elevation,t.Stats.Defense,s.Config))+0.1;}
   else if(cmd is MoveUnit move){var res=GameEngine.Apply(s,cmd);if(!res.Success)throw new Exception("enumeration rejected");var u=res.NewState.Player(me).UnitsOnBoard.First(u=>u.Id==move.UnitId);var old=before[u.Id];var op=res.NewState.ActivePlayer==me?Opportunity(res.NewState,u):0;score=0.92*(op-old.op)+approach*(old.dist-Dist(u))-risk*(RiskAt(u)-old.risk)+0.04*(u.Elevation-s.Player(me).UnitsOnBoard.First(t=>t.Id==u.Id).Elevation);}
   else if(cmd is DeployUnit deploy){var stats=mine.Barracks[deploy.TemplateIndex].Stats;var u=new Unit(s.NextEntityId,me,stats,deploy.Cell,s.Board.TileAt(deploy.Cell).Elevation);score=0.55*stats.PointCost-risk*RiskAt(u)-0.1*Dist(u);}
   else continue;
   score+=rng.NextDouble()*1e-6;
   if(score>bs){best=cmd;bs=score;}
  }
  return best;
 }
 static double ValueDamage(Unit t,int damage){int hit=Math.Min(t.CurrentHp,damage);return t.Stats.PointCost*(0.55*hit/t.Stats.Health+(damage>=t.CurrentHp?0.45:0));}
}
