using HexWars.Engine;
string root=Directory.GetCurrentDirectory();
Console.WriteLine("NEGATIVE CONTROL: original K0 seed21 script under K3");
var state=GameFactory.Build(new GameSetup(GameMode.Annihilation,9,7,0,21,turnActions:3));int step=0;
foreach(string line in File.ReadAllLines(Path.Combine(root,"alpha-seed21-k0-original.wire"))){step++;if(!CommandWire.TryRead(line,out var cmd))throw new Exception("bad wire");var r=GameEngine.Apply(state,cmd!);Console.WriteLine($"step{step} {line}: accepted={r.Success}; reason={r.Reason}; activeAfter={r.NewState.ActivePlayer}; remainingAfter={r.NewState.Config.TurnPolicy.RemainingActions(r.NewState)}");if(!r.Success){if(step!=4||r.Reason!=RejectionReason.NotYourTurn)throw new Exception("unexpected negative-control result");break;}state=r.NewState;}
Console.WriteLine("K3 POSITIVE CONTROL: charge/charge seed5 full replay and fresh activation");
state=GameFactory.Build(new GameSetup(GameMode.Annihilation,9,7,0,5,turnActions:3));step=0;
foreach(string line in File.ReadAllLines(Path.Combine(root,"fresh-activation-seed05.wire"))){step++;if(!CommandWire.TryRead(line,out var cmd))throw new Exception("bad wire");var before=state;var r=GameEngine.Apply(state,cmd!);if(!r.Success)throw new Exception("replay rejected "+step+" "+r.Reason);state=r.NewState;if(step>=26&&step<=31)Console.WriteLine($"step{step} {line}: issuer={cmd!.Issuer}; beforeActions={before.Config.TurnPolicy.RemainingActions(before)}; afterActions={state.Config.TurnPolicy.RemainingActions(state)}; activeAfter={state.ActivePlayer}; alive={string.Join(",",state.Players.SelectMany(p=>p.UnitsOnBoard.Where(u=>u.IsAlive).Select(u=>u.Id)))}");}
Console.WriteLine($"Full K3 replay accepted {step} commands; over={state.IsGameOver};winner={state.Winner};round={state.Round}");
Console.WriteLine("UI BUDGET CONTROL: two movement hops by the same unit count once");
state=GameFactory.Build(new GameSetup(GameMode.Annihilation,9,7,0,7,turnActions:3));
foreach(string line in new[]{"M 0 1 1 0","M 0 1 2 0","M 0 3 2 2"}){if(!CommandWire.TryRead(line,out var cmd))throw new Exception("bad wire");var r=GameEngine.Apply(state,cmd!);if(!r.Success)throw new Exception("budget witness illegal");state=r.NewState;Console.WriteLine($"{line}: uniqueMovedUnits={state.MovedUnitIds.Count};remaining={state.Config.TurnPolicy.RemainingActions(state)}");}
