# HexWars browser-default K3 follow-up evidence

120 complete engine matches on the actual browser-default three-action pace, with fixed seeds1–24 for reproducibility instead of the browser's random session seed. Same controllers and seeds as the original whole-army K0 study; no training or retuning. Read `findings.md` and frozen `protocol.md` for the scope correction and limitations. No new manually directed K3 game: these are bot matches plus inspected/replayed mechanism controls.

Engine snapshot main1cd5f6933702853ef1ed83a4f9f7f865175a5954, DLL SHA256459f67ad83cd61576d034ca1f9fc25d3dc3974fa4c25f96d6257fe6d53817312. Requires .NET10 SDK; provide that engine binary separately. Projects accept an absolute engine override; default is sibling `../engine/HexWars.Engine.dll`. Outputs use cwd.

```sh
# From this extracted directory, reproduce small mechanism controls:
dotnet run --project probes/Probes.csproj -c Release -p:HexWarsEngineDll=/absolute/path/HexWars.Engine.dll
# This deliberately rejects the fourth K0-script command under K3, then validates
# an entire37-command K3 game plus movement-budget examples.

# Rebuild only:
dotnet build TurnOrder.csproj -c Release -p:HexWarsEngineDll=/absolute/path/HexWars.Engine.dll

# Reproduce120matches in a fresh output directory to preserve original receipts:
mkdir /tmp/hexwars-tempo-k3-rerun
cd /tmp/hexwars-tempo-k3-rerun
dotnet run --project /absolute/path/extracted/turn-order-k3/TurnOrder.csproj -c Release -p:HexWarsEngineDll=/absolute/path/HexWars.Engine.dll
```

Main receipts: all120 `replays/*.jsonl`, `matches.csv`, `summary.json`, `matched-comparison.json`, `fresh-activation-receipts.json`, `fresh-activation-seed05.wire`, `k3-mechanism-controls.txt`. K0 original sequence is retained solely as a negative control. `artifact-hashes.json` authenticates included text receipts/source except itself. Archive excludes bin/obj.
