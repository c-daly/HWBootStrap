# Frozen K3 browser-default follow-up — 2026-09-27

Scope correction, not outcome-driven tuning: parent inspected actual SetupForm execution/UI and found default turnActions3 plus randomized seed. Earlier whole-army K0 tests describe selectable whole-army mode and engine GameSetup.Default, not the default web session.

Frozen before follow-up results: same seeds1–24, same five matchups (Greedy/Greedy, Charge/Charge, Hold/Hold, Charge/Hold, Hold/Charge), same controller code/weights and tie-break seeds. Change only GameSetup.TurnActions from0 to3. Public game setup defaults otherwise9x7/no biomes/three standard starters/zero bank/no fog; reproducible seed set replaces randomized session seed.120 games;2500command external cap; engine round100 terminal rule unchanged.

Retain complete command/state traces and CSV, compare only matched seed/style cells with original K0 evidence. Measure P0/P1 wins and draw, multikill turns, first-kill correlation, empty-army reserve stalls. Test original alpha-seed21 command sequence under K3 separately: exact same uninterrupted whole-army wipe should fail when auto-handoff occurs. No production rule changes, training, controller retuning or original-result overwrites.
