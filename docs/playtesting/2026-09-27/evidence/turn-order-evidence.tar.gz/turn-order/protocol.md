# Frozen bounded playtest protocol
Frozen before any matches, 2026-09-27. Source main 1cd5f6933702853ef1ed83a4f9f7f865175a5954.

- Actual GameFactory.Build public default rules, varying only board seed 1..24 (includes default seed7). Mirrored auto-placement; 9x7, three starter units each, zero starting bank, no biomes, damage floor1, full-army turns, no fog. No custom unit designs.
- Primary matches: Greedy vs Greedy; charge vs charge; hold vs hold; charge vs hold and hold vs charge = 120 matches. Independent deterministic tie-break streams for seats.
- Counterfactual: KActions=2 for charge-vs-charge and both charge/hold seat orders, seeds1..12 =36 matches; label separately, do not recommend on win-rate alone.
- Maximum 2500 commands per match; actual engine round100 ending distinguished from external command cap. Save every command, damage/kill and all unit positions each step in JSONL; reject any illegal transition.
- Metrics: P0/P1 win/draw/cap, rounds, first attack/kill seat and round, first-killer winner correlation, maximum kills in one uninterrupted turn, and any final surviving units. Inspect default seed7 representative full command trace.
- Baseline Greedy is deliberately not assumed strong: it ignores partial HP in its heuristic. Bespoke charge/hold use the same tactical choices and differ only in approach/risk weights. They prioritize legal damage, support move-to-fire and estimate next-turn enemy reachable fire; no hidden search or training. Hold may expose controller stalemates. Custom design exploits are outside this role.
- Diagnose mirrored spawn/terrain/distance properties directly on all24 seeds; do not infer global initiative fairness from one controller matchup.
- Small exploratory follow-ups permitted only when explicitly labeled separately after seeing results. No rule or production source changes.
