using HexWars.Engine;
using System.Text.Json;
string root=Directory.GetCurrentDirectory();
if(args[0]=="symmetry"){
 foreach(int w in new[]{8,9,10}){
  int broken=0,reachMismatch=0,total0=0,total1=0;bool witness=false;
  for(int seed=1;seed<=24;seed++){
   var s=GameFactory.Build(new GameSetup(GameMode.Annihilation,w,7,0,seed));
   HexCoord Mir(HexCoord c) {var row=c.R+(c.Q-(c.Q&1))/2;return HexLayout.OffsetToAxial(w-1-c.Q,6-row);}
   int b=s.Board.Tiles.Sum(t=>t.Coord.Neighbors().Count(n=>s.Board.Contains(n)&&HexCoord.Distance(Mir(t.Coord),Mir(n))!=1));broken+=b;
   int a0=s.Player(PlayerId.Player0).UnitsOnBoard.Sum(u=>MovementService.ReachableTiles(s,u).Count),a1=s.Player(PlayerId.Player1).UnitsOnBoard.Sum(u=>MovementService.ReachableTiles(s,u).Count);total0+=a0;total1+=a1;if(a0!=a1)reachMismatch++;
   if(w==9&&seed==7){foreach(var tile in s.Board.Tiles){foreach(var n in tile.Coord.Neighbors()){if(!s.Board.Contains(n)||HexCoord.Distance(Mir(tile.Coord),Mir(n))==1)continue;if(!witness){Console.WriteLine($"WITNESS original {tile.Coord} -> {n} dist1, mirror {Mir(tile.Coord)} -> {Mir(n)} dist{HexCoord.Distance(Mir(tile.Coord),Mir(n))}");witness=true;}}}}
  }
  Console.WriteLine($"width={w}: brokenDirectedAdjacenciesTotal={broken}, initialReachMismatchSeeds={reachMismatch}/24, totalReachP0={total0},P1={total1}");
 }
 return;
}
if(args[0]=="alpha") {
 string[] commands={"M 0 1 3 -1","M 0 2 3 4","M 0 3 2 4","E 0","M 1 5 5 -2","M 1 4 5 4","M 1 6 6 -2","E 1","M 0 1 4 -1","A 0 1 6","A 0 3 5","D 0 2 2 5","M 0 7 4 4","M 0 2 5 3","A 0 7 4","A 0 2 4"};
 foreach(bool fresh in new[]{true,false}){var world=GameFactory.Build(new GameSetup(GameMode.Annihilation,9,7,0,21));foreach(var line in commands){if(!fresh&&(line.StartsWith("D ")||line.StartsWith("M 0 7 ")||line.StartsWith("A 0 7 ")))continue;if(!CommandWire.TryRead(line,out var cmd))throw new Exception("bad alpha wire"+line);var r=GameEngine.Apply(world,cmd!);if(!r.Success)throw new Exception("bad alpha transition"+line+":"+r.Reason);world=r.NewState;}Console.WriteLine($"freshReinforcement={fresh};gameOver={world.IsGameOver};winner={world.Winner};opponents="+string.Join(",",world.Player(PlayerId.Player1).UnitsOnBoard.Where(u=>u.IsAlive).Select(u=>$"{u.Id}:hp{u.CurrentHp}")));}
 File.WriteAllLines(root+"/alpha-seed21.wire",commands);return;
}
var state=GameFactory.Build(GameSetup.Default);string history=root+"/manual-vs-greedy.wire";var logs=new List<object>();
if(File.Exists(history))foreach(var line in File.ReadAllLines(history)){if(!CommandWire.TryRead(line,out var c))throw new Exception("badline "+line);var r=GameEngine.Apply(state,c!);if(!r.Success)throw new Exception("badreplay"+r.Reason);state=r.NewState;}
var bot=new GreedyAgent(743); // Each whole response turn starts with fixed stream; deterministic exploratory opponent, not batch comparison.
void Apply(Command cmd,string by){var old=state;var r=GameEngine.Apply(state,cmd);if(!r.Success)throw new Exception("illegal "+cmd+": "+r.Reason);state=r.NewState;File.AppendAllText(history,CommandWire.Write(cmd)+"\n");var log=new {by,round=old.Round,command=CommandWire.Write(cmd),units=state.Players.SelectMany(p=>p.UnitsOnBoard.Where(u=>u.IsAlive).Select(u=>new{id=u.Id,seat=(int)u.Owner,role=u.DisplayName,cell=u.Cell.ToString(),height=u.Elevation,hp=u.CurrentHp})).ToArray(),gameover=state.IsGameOver,winner=state.Winner?.ToString()};File.AppendAllText(root+"/manual-vs-greedy.jsonl",JsonSerializer.Serialize(log)+"\n");Console.WriteLine(JsonSerializer.Serialize(log));}
foreach(var input in args.Skip(1)){if(!CommandWire.TryRead(input,out var c))throw new Exception("badcmd "+input);Apply(c!,"subagent");}
while(state.ActivePlayer==PlayerId.Player1&&!state.IsGameOver)Apply(bot.Decide(state),"Greedy");
Console.WriteLine("CURRENT round="+state.Round+" over="+state.IsGameOver+" winner="+state.Winner);
foreach(var p in state.Players)foreach(var u in p.UnitsOnBoard.Where(u=>u.IsAlive))Console.WriteLine($"P{(int)p.Id} {u.Id}:{u.DisplayName} {u.Cell} h{u.Elevation} hp{u.CurrentHp} bank{p.Points}");
if(!state.IsGameOver){var legal=LegalMoves.For(state);foreach(var a in legal.OfType<AttackUnit>())Console.WriteLine("ATTACK "+CommandWire.Write(a));foreach(var u in state.Player(state.ActivePlayer).UnitsOnBoard.Where(u=>u.IsAlive)){Console.WriteLine("UNIT"+u.Id+" MOVES "+string.Join(" ",legal.OfType<MoveUnit>().Where(m=>m.UnitId==u.Id).Select(m=>m.Dest.ToString()+"h"+state.Board.TileAt(m.Dest).Elevation)));foreach(var m in legal.OfType<MoveUnit>().Where(m=>m.UnitId==u.Id)){var next=GameEngine.Apply(state,m).NewState;var attacks=LegalMoves.For(next).OfType<AttackUnit>().Where(a=>a.AttackerId==u.Id).ToArray();if(attacks.Length>0)Console.WriteLine("MOVEFIRE "+CommandWire.Write(m)+": "+string.Join(";",attacks.Select(CommandWire.Write)));}}}
