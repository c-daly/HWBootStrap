# HexWars turn-order playtest evidence

Contains156 batch matches plus1 manually directed subagent-versus-Greedy match. Read `findings.md` and `protocol.md` before interpreting counts. Source snapshot main1cd5f6933702853ef1ed83a4f9f7f865175a5954; shared engine DLL SHA256459f67ad83cd61576d034ca1f9fc25d3dc3974fa4c25f96d6257fe6d53817312. Engine binary is not embedded; provide that snapshot's built `HexWars.Engine.dll`. No repository source was modified.

Requires .NET10 SDK. From this extracted directory:

```sh
# Rebuild without playing games:
dotnet build TurnOrder.csproj -c Release -p:HexWarsEngineDll=/absolute/path/HexWars.Engine.dll
# Read-only validation of the included manual command history:
dotnet run --project probes/Probes.csproj -c Release -p:HexWarsEngineDll=/absolute/path/HexWars.Engine.dll -- manual
# Small geometry and reinforcement mechanism controls:
dotnet run --project probes/Probes.csproj -c Release -p:HexWarsEngineDll=/absolute/path/HexWars.Engine.dll -- symmetry
dotnet run --project probes/Probes.csproj -c Release -p:HexWarsEngineDll=/absolute/path/HexWars.Engine.dll -- alpha
```

To rerun the156-game suite, use a fresh output directory to preserve these original receipts:

```sh
mkdir /tmp/hexwars-tempo-rerun
cd /tmp/hexwars-tempo-rerun
dotnet run --project /absolute/path/extracted/turn-order/TurnOrder.csproj -c Release -p:HexWarsEngineDll=/absolute/path/HexWars.Engine.dll
```

All harness outputs use the process's current working directory. If no engine property is supplied, projects look for a sibling `../engine/HexWars.Engine.dll` relative to this evidence directory. Probes `manual` with no additional arguments only validates existing history; explicit wire commands append chosen moves and the opponent's response. Its history and JSONL retain the actual played game even though the exploratory opponent resets its RNG each response turn.

Key receipts: `matches.csv`, `summary.json`, all156 `replays/*.jsonl`, `manual-vs-greedy.wire`, `manual-vs-greedy.jsonl`, `alpha-seed21.wire`, `alpha-control.txt`, `symmetry.csv`, `symmetry-controls.txt`. `artifact-hashes.json` authenticates all included text receipts and sources except itself. `bin/` and `obj/` are excluded from the archive.
