using HexWars.Engine;
using System.Text.Json;
class Program {
static string Root=Environment.GetEnvironmentVariable("HEXWARS_BALANCE_RECEIPTS") ?? Directory.GetCurrentDirectory();
static object Snap(GameState s)=>new {round=s.Round,active=(int)s.ActivePlayer,over=s.IsGameOver,winner=(int?)s.Winner, players=s.Players.Select(p=>new{seat=(int)p.Id,points=p.Points,army=p.UnitsOnBoard.Count,health=p.UnitsOnBoard.Sum(u=>u.CurrentHp),kills=p.DestroyedValue,generators=p.Generators.Count,templates=p.Barracks.Count,eliminated=WinCheck.IsEliminated(s,p.Id)})};
static Unit Find(GameState s,int id)=>s.Players.SelectMany(p=>p.UnitsOnBoard).First(u=>u.Id==id);
static int Dmg(GameState s, Unit a, Unit b)=>CombatResolver.ComputeDamage(a.Stats.Damage,a.Elevation,b.Elevation,b.Stats.Defense,s.Config);
static double AttackValue(GameState s,AttackUnit a){var u=Find(s,a.AttackerId);var t=Find(s,a.TargetId);int d=Dmg(s,u,t);return (d>=t.CurrentHp?100+t.Stats.PointCost:0)+Math.Min(d,t.CurrentHp)*5+(t.Stats.Damage>0?2:0);}
static Command Choose(GameState s,bool bank){
 var me=s.ActivePlayer;var p=s.Player(me);var opp=s.Opponent(me);
 if(s.PlacingStartingUnits)return new FinishPlacement(me);
 if(false&&bank&&!p.Barracks.Any(t=>t.Name=="Pebble"))return new CreateUnit(me,new UnitStats(1,0,0,0,0,0,0,0,0),"Pebble");
 var legal=LegalMoves.For(s); var attacks=legal.OfType<AttackUnit>().OrderByDescending(a=>AttackValue(s,a)).ThenBy(CommandWire.Write).ToArray();
 if(attacks.Length>0&&AttackValue(s,attacks[0])>0)return attacks[0];
 if(!bank){var deploy=legal.OfType<DeployUnit>().Where(d=>p.Barracks[d.TemplateIndex].Stats.Damage>0).OrderByDescending(d=>p.Barracks[d.TemplateIndex].Stats.Range+p.Barracks[d.TemplateIndex].Stats.Damage).ThenBy(d=>opp.UnitsOnBoard.Select(e=>HexCoord.Distance(d.Cell,e.Cell)).DefaultIfEmpty(0).Min()).FirstOrDefault();if(deploy!=null)return deploy;}
 Command best=new EndTurn(me);double bestScore=0;
 foreach(var m in legal.OfType<MoveUnit>()){
 var u=Find(s,m.UnitId);if(opp.UnitsOnBoard.Count==0)continue;
 double before=opp.UnitsOnBoard.Min(e=>HexCoord.Distance(u.Cell,e.Cell));
 var r=GameEngine.Apply(s,m);if(!r.Success)throw new Exception("legal move rejected "+r.Reason);
 var n=Find(r.NewState,m.UnitId);double after=opp.UnitsOnBoard.Min(e=>HexCoord.Distance(n.Cell,e.Cell));
 double score=(before-after)*1.0;
 var shot=opp.UnitsOnBoard.Where(e=>TargetingService.CanTarget(r.NewState,n,e.Cell,e.Elevation)).Select(e=>(Dmg(r.NewState,n,e)>=e.CurrentHp?30:0)+Math.Min(Dmg(r.NewState,n,e),e.CurrentHp)*3).DefaultIfEmpty(0).Max();
 score+=shot;
 if(score>bestScore+0.00001){best=m;bestScore=score;}
 }
 return best;
}
static object Run(int seed,int bankSeat){
 string label=$"stockseed{seed}-bank{bankSeat}";var setup=new GameSetup(GameMode.Annihilation,9,7,0,seed);var s=GameFactory.Build(setup);
 using var w=new StreamWriter(Path.Combine(Root,label+".jsonl"));w.WriteLine(JsonSerializer.Serialize(new {setup=setup.ToWire(),initial=Snap(s)}));
 int i=0, firstKill=-1,firstKillSeat=-1, emptyAt=-1,emptySeat=-1, firstReinforce=-1;int[] deployments=new int[2];int[] attacks=new int[2];
 for(;i<1500&&!s.IsGameOver;i++){
 var c=Choose(s,(int)s.ActivePlayer==bankSeat);var r=GameEngine.Apply(s,c);if(!r.Success)throw new Exception($"Rejected {CommandWire.Write(c)} {r.Reason}");
 if(c is AttackUnit){attacks[(int)c.Issuer]++;if(r.NewState.Opponent(c.Issuer).UnitsOnBoard.Count<s.Opponent(c.Issuer).UnitsOnBoard.Count&&firstKill<0){firstKill=s.Round;firstKillSeat=(int)c.Issuer;}}
 if(c is DeployUnit){deployments[(int)c.Issuer]++;if(firstReinforce<0)firstReinforce=s.Round;}
 s=r.NewState;
 if(emptyAt<0&&!s.IsGameOver){foreach(var p in s.Players)if(p.UnitsOnBoard.Count==0){emptyAt=s.Round;emptySeat=(int)p.Id;}}
 w.WriteLine(JsonSerializer.Serialize(new {i,wire=CommandWire.Write(c),state=Snap(s)}));
 }
 var result=new {label,seed,bankSeat,commands=i,final=Snap(s),firstKill,firstKillSeat,firstReinforce,deployments,attacks,emptyArmyRound=emptyAt,emptyArmySeat=emptySeat,stallRounds=emptyAt<0?0:s.Round-emptyAt};
 File.WriteAllText(Path.Combine(Root,label+".result.json"),JsonSerializer.Serialize(result,new JsonSerializerOptions{WriteIndented=true}));Console.WriteLine(JsonSerializer.Serialize(result));return result;
}
static object Probe(GameMode mode,int points,int seed){
 var s=GameFactory.Build(new GameSetup(mode,9,7,points,seed));var initial=Snap(s);var commands=new List<object>();
 void Apply(Command c){var r=GameEngine.Apply(s,c);commands.Add(new{wire=CommandWire.Write(c),accepted=r.Success,reason=r.Reason.ToString(),state=Snap(r.NewState)});if(r.Success)s=r.NewState;}
 var cell=s.Board.DeploymentZone(PlayerId.Player0).First(c=>s.Players.SelectMany(p=>p.UnitsOnBoard).All(u=>u.Cell!=c));
 Apply(new DeployGenerator(PlayerId.Player0,cell));int genId=s.Player(PlayerId.Player0).Generators.First().Id;
 Apply(new EndTurn(PlayerId.Player0));Apply(new AttackUnit(PlayerId.Player1,4,genId));
 var legal=LegalMoves.For(s); bool enemyCanMoveOntoGenerator=legal.OfType<MoveUnit>().Any(m=>m.Dest==cell);
 Apply(new EndTurn(PlayerId.Player1));
 var result=new {label=$"probe-{mode}-{points}-{seed}",mode=mode.ToString(),points,seed,initial,generatorsEnabled=s.Config.GeneratorsEnabled,genId,generatorCell=cell.ToString(),enemyCanMoveOntoGenerator,commands,final=Snap(s)};
 File.WriteAllText(Path.Combine(Root,result.label+".json"),JsonSerializer.Serialize(result,new JsonSerializerOptions{WriteIndented=true}));return result;
}
static void Extras(){
 var notes=new List<object>();
 // Re-open seed7's exact stock-catalog stall at its first empty army position.
 var path=Path.Combine(Root,"stockseed7-bank1.jsonl");var lines=File.ReadAllLines(path);var setup=GameSetup.Parse(JsonDocument.Parse(lines[0]).RootElement.GetProperty("setup").GetString()!);var s=GameFactory.Build(setup);int prefix=0;
 foreach(var line in lines.Skip(1)){var doc=JsonDocument.Parse(line);var c=CommandWire.Read(doc.RootElement.GetProperty("wire").GetString()!);var r=GameEngine.Apply(s,c);if(!r.Success)throw new Exception("replay rejected");s=r.NewState;prefix++;if(s.Player(PlayerId.Player1).UnitsOnBoard.Count==0)break;}
 var stalled=Snap(s);var legalByPlayer=new List<object>();var t=s;for(int i=0;i<2;i++){legalByPlayer.Add(new{seat=(int)t.ActivePlayer,commands=LegalMoves.For(t).GroupBy(c=>c.GetType().Name).ToDictionary(g=>g.Key,g=>g.Count())});t=GameEngine.Apply(t,new EndTurn(t.ActivePlayer)).NewState;}
 var recovery=new List<string>();while(!s.IsGameOver&&recovery.Count<100){var c=Choose(s,false);recovery.Add(CommandWire.Write(c));s=GameEngine.Apply(s,c).NewState;}
 notes.Add(new{kind="counterplay-stock-redeploy",source="stockseed7-bank1.jsonl",prefix,stalled,legalByPlayer,recovery,final=Snap(s)});
 foreach(int seed in new[]{7,19}){
  s=GameFactory.Build(new GameSetup(GameMode.Territory,9,7,40,seed));var actions=new List<object>();
  void Step(Command c){var r=GameEngine.Apply(s,c);actions.Add(new{wire=CommandWire.Write(c),success=r.Success,reason=r.Reason.ToString(),state=Snap(r.NewState)});if(r.Success)s=r.NewState;}
  var cell=s.Player(PlayerId.Player0).UnitsOnBoard.First().Cell;
  Step(new BuildGenerator(PlayerId.Player0,cell));int gid=s.Player(PlayerId.Player0).Generators.First().Id;
  // Move builder away legally, leaving a capturable generator.
  var vacate=LegalMoves.For(s).OfType<MoveUnit>().First(m=>m.UnitId==1);Step(vacate);Step(new EndTurn(PlayerId.Player0));
  int targetUnit=4;bool arrived=false;int caps=0;
  for(int i=0;i<50&&!s.IsGameOver;i++){
   if(s.ActivePlayer==PlayerId.Player0){Step(new EndTurn(s.ActivePlayer));continue;}
   var u=Find(s,targetUnit);
   if(u.Cell==cell){arrived=true;Step(new AttackUnit(PlayerId.Player1,targetUnit,gid));
    var cap=GameEngine.Apply(s,new CaptureHex(PlayerId.Player1,cell));if(cap.Success){Step(new CaptureHex(PlayerId.Player1,cell));caps++;break;}
    Step(new EndTurn(PlayerId.Player1));continue;}
   var move=LegalMoves.For(s).OfType<MoveUnit>().Where(m=>m.UnitId==targetUnit).OrderBy(m=>HexCoord.Distance(m.Dest,cell)).FirstOrDefault();
   if(move!=null&&HexCoord.Distance(move.Dest,cell)<HexCoord.Distance(u.Cell,cell))Step(move);else Step(new EndTurn(s.ActivePlayer));
  }
  notes.Add(new{kind="territory-generator-counterplay",seed,cell=cell.ToString(),arrived,captures=caps,generatorOwner=(int)s.Players.SelectMany(p=>p.Generators).First(g=>g.Id==gid).Owner,actions,final=Snap(s)});
 }
 // Default legal bounty converted to raw-wire income, no injected board/points.
 s=GameFactory.Build(GameSetup.Default);var raw=new List<object>();foreach(var line in File.ReadAllLines(Path.Combine(Root,"stockseed7-bank1.jsonl")).Skip(1)){
  var c=CommandWire.Read(JsonDocument.Parse(line).RootElement.GetProperty("wire").GetString()!);s=GameEngine.Apply(s,c).NewState;raw.Add(new{wire=CommandWire.Write(c),state=Snap(s)});if(s.Player(PlayerId.Player1).Points>=10)break;}
 var gc=s.Board.DeploymentZone(PlayerId.Player1).First(c=>s.Players.SelectMany(p=>p.UnitsOnBoard).All(u=>u.Cell!=c));var gcmd=new DeployGenerator(PlayerId.Player1,gc);var gr=GameEngine.Apply(s,gcmd);raw.Add(new{wire=CommandWire.Write(gcmd),success=gr.Success,reason=gr.Reason.ToString(),state=Snap(gr.NewState)});s=gr.NewState;
 foreach(var p in new[]{PlayerId.Player1,PlayerId.Player0}){var c=new EndTurn(p);s=GameEngine.Apply(s,c).NewState;raw.Add(new{wire=CommandWire.Write(c),state=Snap(s)});}
 notes.Add(new{kind="default-bounty-raw-wire-generator",setup=GameSetup.Default.ToWire(),raw,final=Snap(s)});
 File.WriteAllText(Path.Combine(Root,"counterplay-results.json"),JsonSerializer.Serialize(notes,new JsonSerializerOptions{WriteIndented=true}));
 int checkedGames=0;foreach(var file in Directory.GetFiles(Root,"*.jsonl")){var ll=File.ReadAllLines(file);var gs=GameFactory.Build(GameSetup.Parse(JsonDocument.Parse(ll[0]).RootElement.GetProperty("setup").GetString()!));foreach(var line in ll.Skip(1)){var c=CommandWire.Read(JsonDocument.Parse(line).RootElement.GetProperty("wire").GetString()!);var rr=GameEngine.Apply(gs,c);if(!rr.Success)throw new Exception(file+" failed "+c);gs=rr.NewState;}if(!gs.IsGameOver)throw new Exception(file+" not finished");checkedGames++;}
 Console.WriteLine(JsonSerializer.Serialize(new{replayedCompleteGames=checkedGames,probes=notes.Count}));
}
static void Main(){Extras();}
}
