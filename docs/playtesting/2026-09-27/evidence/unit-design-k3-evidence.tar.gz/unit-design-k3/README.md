# Reproduce the K=3 unit-design follow-up

Requires .NET SDK 10 and a separately built release `HexWars.Engine.dll`. All 42 games explicitly use `turnActions:3`, the browser SetupForm's default pace. The six fixed seeds and equal-budget construction are frozen in `criteria.md`. No Unity Editor, server, learned policy or external service is required.

Original DLL SHA256:

```
459f67ad83cd61576d034ca1f9fc25d3dc3974fa4c25f96d6257fe6d53817312
```

From this extracted `unit-design-k3` directory:

```sh
unit_design_evidence_dir="$PWD"
unit_design_engine_dll="/absolute/path/to/HexWars.Engine.dll"
mkdir -p reproduction
cd reproduction
dotnet run --project "$unit_design_evidence_dir/Probe.csproj" -c Release \
  -p:HexWarsEngineDll="$unit_design_engine_dll" > run.log 2>&1
```

Output is written to the working directory: `matches.json`, `traces.json`, `designs.json` and `breakpoints.json`. Use a fresh directory to preserve the included evidence. The actual original command used `-p:HexWarsEngineDll=/tmp/hexwars-balance-20260927/engine/HexWars.Engine.dll`.

`compact-results.json`, `summary.json` and `representative-replays.json` are editorial extracts from the original full outputs; the harness does not regenerate them. `artifact-sha256.json` authenticates all JSON evidence. The archive excludes `bin`, `obj` and the engine DLL. Repeating with another engine revision is a new experiment.

`controller-k0-to-k3.diff` shows the limited automatic-handoff adaptations to the original K=0 controller. The twelve manual K=0 encounter actions were not repeated and are available only in the separate K=0 evidence bundle. No production game rules were changed.
