using HexWars.Engine;
using System.Text.Json;
using System.Security.Cryptography;

var output = Directory.GetCurrentDirectory();
var json = new JsonSerializerOptions { WriteIndented = true, IncludeFields = true };
var starters = BarracksCatalog.DefaultTemplates.Take(3).ToArray();
var fortified = new UnitTemplate("Fortified Sniper", new UnitStats(3,2,0,2,2,5,1,4,1));
var balanced = new UnitTemplate("Balanced Fighter", new UnitStats(3,3,0,3,2,3,1,4,1));
var cheap = new UnitTemplate("Cheap Fighter", new UnitStats(1,2,0,2,1,1,1,1,1));
File.WriteAllText(output+"/designs.json",JsonSerializer.Serialize(starters.Concat(new[]{fortified,balanced,cheap}).Select(x=>new{x.Name,Cost=x.Stats.PointCost,x.Stats}),json));
var results = new List<object>();
var traces = new List<object>();
int[] seeds={1,2,3,7,11,19};
foreach(var seed in seeds)
{
    var s = GameFactory.Build(new GameSetup(GameMode.Annihilation,9,7,0,seed,turnActions:3));
    Run($"normal-starters-{seed}",s,"starter trio","starter trio",seed,false);
}
foreach(var matchup in new[]{(name:"sniper-health",a:starters[2],ac:3,b:fortified,bc:3),(name:"striker-balanced",a:starters[1],ac:3,b:balanced,bc:3),(name:"striker-cheap",a:starters[1],ac:3,b:cheap,bc:6)})
foreach(var seed in seeds)
foreach(var swap in new[]{false,true})
{
    var s = GameFactory.Build(new GameSetup(GameMode.Annihilation,9,7,0,seed,armySize:6,brutes:0,strikers:6,snipers:0,turnActions:3));
    var left=swap?matchup.b:matchup.a; var lc=swap?matchup.bc:matchup.ac;
    var right=swap?matchup.a:matchup.b; var rc=swap?matchup.ac:matchup.bc;
    s = ReArmy(s,left,lc,right,rc);
    Run($"{matchup.name}-{seed}-{(swap?"swap":"base")}",s,left.Name,right.Name,seed,true);
}
File.WriteAllText(output+"/matches.json",JsonSerializer.Serialize(results,json));
File.WriteAllText(output+"/traces.json",JsonSerializer.Serialize(traces,json));
var math = new List<object>();
foreach(var a in starters)
foreach(var b in starters)
foreach(var elevation in new[]{-2,-1,0,1,2})
{
 var damage=CombatResolver.ComputeDamage(a.Stats.Damage,Math.Max(elevation,0),Math.Max(-elevation,0),b.Stats.Defense,GameFactory.Build(GameSetup.Default).Config);
 math.Add(new{Attacker=a.Name,Target=b.Name,ElevationDifference=elevation,Damage=damage,Hits=(int)Math.Ceiling(b.Stats.Health/(double)damage)});
}
File.WriteAllText(output+"/breakpoints.json",JsonSerializer.Serialize(math,json));
Console.WriteLine($"Finished {results.Count} matches. Artifacts in {output}");

GameState ReArmy(GameState s,UnitTemplate a,int an,UnitTemplate b,int bn)
{
 var ps=new List<PlayerState>(); int id=1;
 foreach(var pid in new[]{PlayerId.Player0,PlayerId.Player1})
 {
   var t=pid==PlayerId.Player0?a:b;int n=pid==PlayerId.Player0?an:bn;
   var units=s.Player(pid).UnitsOnBoard.Take(n).Select(u=>new Unit(id++,pid,t.Stats,u.Cell,u.Elevation,t.Name)).ToArray();
   ps.Add(new PlayerState(pid,0,Array.Empty<UnitTemplate>(),units));
 }
 return new GameState(s.Board,s.Config,ps,s.ActivePlayer,s.Round,id);
}
void Run(string id,GameState start,string p0,string p1,int seed,bool synthetic)
{
 var s=start; int actions=0; int turns=0;var trace=new List<object>();
 var damageByName=new Dictionary<string,int>(); var killsByName=new Dictionary<string,int>();
 while(!s.IsGameOver && s.Round<=40)
 {
   var owner=s.ActivePlayer;
   if(!synthetic)
   {
      // Ordinary games may buy reinforcements once bounties accumulate. Prefer mobile shooters,
      // then any affordable template so an empty army does not wait indefinitely.
      while(true)
      {
         var deployments=LegalMoves.For(s).OfType<DeployUnit>().OrderByDescending(c=>s.Player(owner).Barracks[c.TemplateIndex].Stats.Damage>0 && s.Player(owner).Barracks[c.TemplateIndex].Stats.Movement>0).ThenByDescending(c=>s.Player(owner).Barracks[c.TemplateIndex].Stats.Range).ToArray();
         if(deployments.Length==0)break;
         Apply(deployments[0]);if(s.IsGameOver || s.ActivePlayer!=owner)break;
      }
   }
   var unitOrder=s.Player(owner).UnitsOnBoard.Where(u=>u.IsAlive).OrderByDescending(u=>u.Stats.Range).ThenBy(u=>u.Id).Select(u=>u.Id).ToArray();
   foreach(var uid in unitOrder)
   {
    if(s.IsGameOver || s.ActivePlayer!=owner || s.Opponent(owner).UnitsOnBoard.Count==0)break;
    var found=s.Player(owner).UnitsOnBoard.Where(u=>u.Id==uid).ToArray();if(found.Length==0)continue;
    var u=found[0];
    var positions=MovementService.ReachableTiles(s,u).Prepend(u.Cell).ToArray();
    HexCoord chosen=u.Cell; int target=-1;double best=double.NegativeInfinity;
    foreach(var pos in positions)
    {
      var moved=u.WithCell(pos,s.Board.TileAt(pos).Elevation);
      var candidate=s;
      if(pos!=u.Cell){var result=GameEngine.Apply(s,new MoveUnit(owner,uid,pos));if(!result.Success)throw new Exception("Generated illegal movement");candidate=result.NewState;}
      // A final-action move cannot supply an immediate shot after the automatic handoff.
      if(candidate.ActivePlayer!=owner)continue;
      double risk=0;
      foreach(var enemy in candidate.Opponent(owner).UnitsOnBoard)
      {
        if(!TargetingService.CanTarget(candidate,enemy,pos,moved.Elevation))continue;
        int dmg=CombatResolver.ComputeDamage(enemy.Stats.Damage,enemy.Elevation,moved.Elevation,moved.Stats.Defense,candidate.Config);
        risk+=Math.Min(moved.CurrentHp,dmg)/(double)moved.CurrentHp*8;
      }
      foreach(var enemy in candidate.Opponent(owner).UnitsOnBoard)
      {
        if(!TargetingService.CanTarget(candidate,moved,enemy.Cell,enemy.Elevation))continue;
        int dmg=CombatResolver.ComputeDamage(moved.Stats.Damage,moved.Elevation,enemy.Elevation,enemy.Stats.Defense,candidate.Config);
        bool kill=dmg>=enemy.CurrentHp;
        double score=100+(kill?30:0)+Math.Min(dmg,enemy.CurrentHp)/(double)enemy.Stats.Health*enemy.Stats.PointCost - risk*0.6 + moved.Elevation*0.2;
        if(score>best+1e-8){best=score;chosen=pos;target=enemy.Id;}
      }
    }
    if(target<0)
    {
      double bestMove=double.NegativeInfinity;
      foreach(var pos in positions)
      {
        int d=s.Opponent(owner).UnitsOnBoard.Min(e=>HexCoord.Distance(pos,e.Cell));
        // Persistent approach, with a small elevation preference. No hidden information is used: fog is off.
        double score=-d*3+s.Board.TileAt(pos).Elevation*0.4;
        if(score>bestMove+1e-8){bestMove=score;chosen=pos;}
      }
    }
    if(chosen!=u.Cell)Apply(new MoveUnit(owner,uid,chosen));
    if(target>=0 && !s.IsGameOver && s.ActivePlayer==owner)Apply(new AttackUnit(owner,uid,target));
   }
   if(!s.IsGameOver && s.ActivePlayer==owner)Apply(new EndTurn(owner));
   turns++;
 }
 results.Add(new{Id=id,Seed=seed,TurnActions=3,Synthetic=synthetic,P0=p0,P1=p1,StartP0Cost=start.Player(PlayerId.Player0).UnitsOnBoard.Sum(u=>u.Stats.PointCost),StartP1Cost=start.Player(PlayerId.Player1).UnitsOnBoard.Sum(u=>u.Stats.PointCost),Winner=s.Winner?.ToString(),Terminal=s.IsGameOver,Censored=!s.IsGameOver,Round=s.Round,Actions=actions,Survivors=s.Players.Select(p=>new{Seat=p.Id.ToString(),Count=p.UnitsOnBoard.Count,HP=p.UnitsOnBoard.Sum(u=>u.CurrentHp),Points=p.Points,Destroyed=p.DestroyedValue}).ToArray(),DamageByName=damageByName,KillsByName=killsByName});
 traces.Add(new{Id=id,TurnActions=3,SetupBoard=start.Board.Tiles.Select(t=>new{q=t.Coord.Q,r=t.Coord.R,z=t.Elevation}).ToArray(),Initial=start.Players.SelectMany(p=>p.UnitsOnBoard).Select(U).ToArray(),Trace=trace});
 Console.WriteLine($"{id}: winner={s.Winner?.ToString()??"none"}, terminal={s.IsGameOver}, r={s.Round}");
 void Apply(Command command)
 {
    var before=s;var result=GameEngine.Apply(s,command);if(!result.Success)throw new Exception($"{id} illegal {command}: {result.Reason}");s=result.NewState;actions++;
    object? hit=null;
    if(command is AttackUnit attack)
    {
     var attacker=before.Player(before.ActivePlayer).UnitsOnBoard.Single(u=>u.Id==attack.AttackerId);var victim=before.Opponent(before.ActivePlayer).UnitsOnBoard.Single(u=>u.Id==attack.TargetId);var after=s.Opponent(before.ActivePlayer).UnitsOnBoard.Where(u=>u.Id==victim.Id).ToArray();int hp=after.Length>0?after[0].CurrentHp:0;
     var name=attacker.DisplayName;damageByName[name]=damageByName.GetValueOrDefault(name)+victim.CurrentHp-hp;if(hp==0)killsByName[name]=killsByName.GetValueOrDefault(name)+1;
     hit=new{Attacker=U(attacker),Target=U(victim),RemainingHp=hp,EffectiveDamage=victim.CurrentHp-hp};
    }
    trace.Add(new{Index=actions,Round=before.Round,Seat=(int)before.ActivePlayer,Command=command.ToString(),NextActivePlayer=(int)s.ActivePlayer,AutomaticHandoff=command is not EndTurn && s.ActivePlayer!=before.ActivePlayer,Hit=hit});
 }
}
object U(Unit u)=>new{u.Id,Owner=(int)u.Owner,Name=u.DisplayName,q=u.Cell.Q,r=u.Cell.R,z=u.Elevation,HP=u.CurrentHp,Cost=u.Stats.PointCost,u.Stats};
