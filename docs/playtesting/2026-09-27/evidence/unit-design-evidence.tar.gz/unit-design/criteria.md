# Frozen evaluation criteria (before execution)

Use release GameFactory.Build 9x7, biomes disabled, DamageFloor=1; zero starting money. No production source changes or learned policy. Record DLL SHA and every accepted command for representative scenarios.

1. Exact damage and health thresholds: all starter pairs on level ground and elevations +/-1,+/-2. This is arithmetic, not a tournament outcome.
2. Legal scripted encounter: Brute versus ranged units at distance 4 on level ground, alternating active seat; identify first-strike, movement, vision and survivability consequences.
3. Synthetic equal-budget army encounters: 60 or 63 points deployed from fixed formations, no reinforcements, default damage/targeting/movement rules; compare three starter strikers/snipers to custom health-efficient or distributed cheap fighters. Swap army seats over six public board seeds [1,2,3,7,11,19], with one deterministic controller for all units. Max 40 rounds; unfinished games reported as censored, not wins.
4. Normal public starter matches: seeds [1,2,3,7,11,19], one Brute/Striker/Sniper each. Do not conflate these with synthetic army comparisons.
5. Paid custom-design probe: establish legal CreateUnit/DeployUnit and exact cost; shared vision probe showing both capability and a counter (spotter loss).

Controller is a bounded tactical heuristic, not expert human play or a minimax proof. Match claims must state sample, seats, construction, and controller. Strong conclusions require exact mechanics or consistent paired outcomes; otherwise mark hypotheses. No production balance tuning during the audit.
