# Reproduce the K=0 unit-design balance probes

**Scope:** these 42 matches and the 12 constructed manual actions use selectable K=0 whole-army pace, not the browser SetupForm default K=3. See the separate `unit-design-k3` follow-up for the K=3 repeat. Original JSON artifacts are unchanged.

These probes use .NET SDK 10 and a separately built current-release `HexWars.Engine.dll`. No Unity Editor, learned policy, server, or external service is required. The evidence was generated from release main `1cd5f69` using engine SHA256:

```
459f67ad83cd61576d034ca1f9fc25d3dc3974fa4c25f96d6257fe6d53817312
```

The archive deliberately excludes the engine DLL and `bin`/`obj` build products. Provide the DLL with the MSBuild property shown below. The original run artifacts remain in this directory; use a fresh working directory to avoid replacing them. Output files are always written to the current working directory.

From this extracted `unit-design` directory, the exact reproduction commands are:

```sh
# Set these to the extracted evidence directory and your release engine DLL.
unit_design_evidence_dir="$PWD"
unit_design_engine_dll="/absolute/path/to/HexWars.Engine.dll"

# This produces matches.json, traces.json, designs.json and breakpoints.json.
mkdir -p reproduction-matches
cd reproduction-matches
dotnet run --project "$unit_design_evidence_dir/Probe.csproj" -c Release \
  -p:HexWarsEngineDll="$unit_design_engine_dll" > run.log 2>&1

# This produces manual-encounters.json.
cd "$unit_design_evidence_dir"
mkdir -p reproduction-manual
cd reproduction-manual
dotnet run --project "$unit_design_evidence_dir/manual/Manual.csproj" -c Release \
  -p:HexWarsEngineDll="$unit_design_engine_dll" > manual.log 2>&1
```

The exact DLL used originally was `/tmp/hexwars-balance-20260927/engine/HexWars.Engine.dll`. Reproducing with another engine revision is a new experiment and might produce different results.

`criteria.md` freezes the scope. `findings.md` explains the hypotheses, limitations and manually inspected counterplay. `compact-results.json`, `summary.json` and `representative-replays.json` are summaries extracted from the original full artifacts; the harness does not regenerate these editorial selections. All match actions are in `traces.json`. The manual encounters include two intentional rejected commands testing movement after firing and loss of shared sight.

After the experiment, only project DLL resolution and output path handling were changed for portability. The tactical controller and original outcome artifacts were not changed or rerun. `original-artifact-sha256.json` authenticates every original JSON artifact. Both portable projects were build-checked against the original DLL; the build logs are included.
