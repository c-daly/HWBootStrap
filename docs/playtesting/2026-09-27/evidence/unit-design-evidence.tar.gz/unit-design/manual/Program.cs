using HexWars.Engine;
using System.Text.Json;
var root=Directory.GetCurrentDirectory();
var cfg=GameFactory.Build(GameSetup.Default).Config;
var tiles=Enumerable.Range(0,11).SelectMany(q=>Enumerable.Range(0,5).Select(r=>new Tile(new HexCoord(q,r),0,TerrainType.Plains))).ToArray();
var board=new Board(tiles,tiles.Where(t=>t.Coord.Q<=1).Select(t=>t.Coord).ToArray(),tiles.Where(t=>t.Coord.Q>=9).Select(t=>t.Coord).ToArray());
var templates=BarracksCatalog.DefaultTemplates;
var records=new List<object>();
GameState State(Unit[] a,Unit[] b,PlayerId active=PlayerId.Player0,int points=0)=>new(board,cfg,new[]{new PlayerState(PlayerId.Player0,points,Array.Empty<UnitTemplate>(),a),new PlayerState(PlayerId.Player1,points,Array.Empty<UnitTemplate>(),b)},active,2,100);
Unit U(int id,PlayerId p,string name,UnitStats stats,int q,int r)=>new(id,p,stats,new HexCoord(q,r),0,name);
void Apply(string scene,ref GameState s,Command command,string thought,bool expect=true)
{
 var before=s;var r=GameEngine.Apply(s,command);if(r.Success!=expect)throw new Exception($"Unexpected {r.Reason}: {command}");s=r.NewState;
 records.Add(new{Scene=scene,Command=command.ToString(),Thought=thought,Accepted=r.Success,Reason=r.Reason.ToString(),Round=s.Round,Active=s.ActivePlayer.ToString(),Winner=s.Winner?.ToString(),Units=s.Players.SelectMany(p=>p.UnitsOnBoard).Select(u=>new{u.Id,u.Name,Owner=(int)u.Owner,q=u.Cell.Q,r=u.Cell.R,u.CurrentHp}),Points=s.Players.Select(p=>p.Points).ToArray()});
}
// Role duel: shooting does not grant a retreat; a Brute absorbs a sniper hit and closes.
var duel=State(new[]{U(1,PlayerId.Player0,"Sniper",templates[2].Stats,6,2)},new[]{U(2,PlayerId.Player1,"Brute",templates[0].Stats,2,2)});
Apply("sniper-brute-level-ground",ref duel,new AttackUnit(PlayerId.Player0,1,2),"At distance4 the sniper can see and fire; 2damage versus2defense becomes the1damage floor.");
Apply("sniper-brute-level-ground",ref duel,new MoveUnit(PlayerId.Player0,1,new HexCoord(7,2)),"Try to kite after firing: the rules deliberately end movement after an attack.",false);
Apply("sniper-brute-level-ground",ref duel,new EndTurn(PlayerId.Player0),"Sniper has no action remaining.");
Apply("sniper-brute-level-ground",ref duel,new MoveUnit(PlayerId.Player1,2,new HexCoord(5,2)),"Brute spends3movement to close to distance1.");
Apply("sniper-brute-level-ground",ref duel,new AttackUnit(PlayerId.Player1,2,1),"Its2damage kills the2HP sniper; durable melee counters this unsupported ranged piece.");
// Shared vision is powerful but disappears when the one spotter dies.
var artillery=new UnitStats(1,6,0,0,0,6,1,0,0); //14points, completely visionless
var spotter=new UnitStats(1,0,0,0,0,0,0,4,1); //6points
var shared=State(new[]{U(1,PlayerId.Player0,"Visionless gun",artillery,1,2),U(2,PlayerId.Player0,"Spotter",spotter,4,2)},new[]{U(3,PlayerId.Player1,"Brute",templates[0].Stats,7,2),U(4,PlayerId.Player1,"Striker",templates[1].Stats,5,2)});
Apply("shared-vision-counterplay",ref shared,new AttackUnit(PlayerId.Player0,1,3),"14point gun fires at range6 using the6point spotter's sight, dealing4 to Brute.");
Apply("shared-vision-counterplay",ref shared,new EndTurn(PlayerId.Player0),"Give defender the counterplay turn.");
Apply("shared-vision-counterplay",ref shared,new AttackUnit(PlayerId.Player1,4,2),"Striker removes the1HP spotter; it is a higher-leverage target than charging the gun.");
Apply("shared-vision-counterplay",ref shared,new EndTurn(PlayerId.Player1),"Return to the gun.");
Apply("shared-vision-counterplay",ref shared,new AttackUnit(PlayerId.Player0,1,3),"Gun retains range but lost all army sight: the second shot must be rejected.",false);
// Cost-free design plus minimum one point body: legal but noncombatant, not evidence it wins.
var paid=GameFactory.Build(new GameSetup(GameMode.Annihilation,9,7,10,7));
var body=new UnitStats(1,0,0,0,0,0,0,0,0);
Apply("paid-cheap-blocker",ref paid,new CreateUnit(PlayerId.Player0,body,"Blocker"),"Custom design is free; the minimum body costs1 point.");
var slot=paid.Player(PlayerId.Player0).Barracks.Count-1;
var dep=LegalMoves.For(paid).OfType<DeployUnit>().First(c=>c.TemplateIndex==slot);
Apply("paid-cheap-blocker",ref paid,dep,"Spend1 point to occupy a deployment cell. This body has no attack, sight or movement.");
File.WriteAllText(root+"/manual-encounters.json",JsonSerializer.Serialize(records,new JsonSerializerOptions{WriteIndented=true}));
Console.WriteLine($"{records.Count} encounter actions checked, including2 intentional rejects.");
