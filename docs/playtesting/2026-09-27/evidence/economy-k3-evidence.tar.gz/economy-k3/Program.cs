using HexWars.Engine;
using System.Text.Json;
class Program {
static string Root=Environment.GetEnvironmentVariable("HEXWARS_BALANCE_RECEIPTS") ?? Directory.GetCurrentDirectory();
static object Snap(GameState s)=>new {round=s.Round,active=(int)s.ActivePlayer,over=s.IsGameOver,winner=(int?)s.Winner, players=s.Players.Select(p=>new{seat=(int)p.Id,points=p.Points,army=p.UnitsOnBoard.Count,health=p.UnitsOnBoard.Sum(u=>u.CurrentHp),kills=p.DestroyedValue,generators=p.Generators.Count,templates=p.Barracks.Count,eliminated=WinCheck.IsEliminated(s,p.Id)})};
static Unit Find(GameState s,int id)=>s.Players.SelectMany(p=>p.UnitsOnBoard).First(u=>u.Id==id);
static int Dmg(GameState s, Unit a, Unit b)=>CombatResolver.ComputeDamage(a.Stats.Damage,a.Elevation,b.Elevation,b.Stats.Defense,s.Config);
static double AttackValue(GameState s,AttackUnit a){var u=Find(s,a.AttackerId);var t=Find(s,a.TargetId);int d=Dmg(s,u,t);return (d>=t.CurrentHp?100+t.Stats.PointCost:0)+Math.Min(d,t.CurrentHp)*5+(t.Stats.Damage>0?2:0);}
static Command Choose(GameState s,bool bank){
 var me=s.ActivePlayer;var p=s.Player(me);var opp=s.Opponent(me);
 if(s.PlacingStartingUnits)return new FinishPlacement(me);
 if(false&&bank&&!p.Barracks.Any(t=>t.Name=="Pebble"))return new CreateUnit(me,new UnitStats(1,0,0,0,0,0,0,0,0),"Pebble");
 var legal=LegalMoves.For(s); var attacks=legal.OfType<AttackUnit>().OrderByDescending(a=>AttackValue(s,a)).ThenBy(CommandWire.Write).ToArray();
 if(attacks.Length>0&&AttackValue(s,attacks[0])>0)return attacks[0];
 if(!bank){var deploy=legal.OfType<DeployUnit>().Where(d=>p.Barracks[d.TemplateIndex].Stats.Damage>0).OrderByDescending(d=>p.Barracks[d.TemplateIndex].Stats.Range+p.Barracks[d.TemplateIndex].Stats.Damage).ThenBy(d=>opp.UnitsOnBoard.Select(e=>HexCoord.Distance(d.Cell,e.Cell)).DefaultIfEmpty(0).Min()).FirstOrDefault();if(deploy!=null)return deploy;}
 Command best=new EndTurn(me);double bestScore=0;
 foreach(var m in legal.OfType<MoveUnit>()){
 var u=Find(s,m.UnitId);if(opp.UnitsOnBoard.Count==0)continue;
 double before=opp.UnitsOnBoard.Min(e=>HexCoord.Distance(u.Cell,e.Cell));
 var r=GameEngine.Apply(s,m);if(!r.Success)throw new Exception("legal move rejected "+r.Reason);
 var n=Find(r.NewState,m.UnitId);double after=opp.UnitsOnBoard.Min(e=>HexCoord.Distance(n.Cell,e.Cell));
 double score=(before-after)*1.0;
 var shot=opp.UnitsOnBoard.Where(e=>TargetingService.CanTarget(r.NewState,n,e.Cell,e.Elevation)).Select(e=>(Dmg(r.NewState,n,e)>=e.CurrentHp?30:0)+Math.Min(Dmg(r.NewState,n,e),e.CurrentHp)*3).DefaultIfEmpty(0).Max();
 score+=shot;
 if(score>bestScore+0.00001){best=m;bestScore=score;}
 }
 return best;
}
static void Main(){
 var notes=new List<object>();
 foreach(var spec in new[]{("k3-seed7-bank0.jsonl",PlayerId.Player0),("k3-seed3-bank1.jsonl",PlayerId.Player1)}){
 var lines=File.ReadAllLines(Path.Combine(Root,spec.Item1));var setup=GameSetup.Parse(JsonDocument.Parse(lines[0]).RootElement.GetProperty("setup").GetString()!);var s=GameFactory.Build(setup);var prefix=new List<string>();
 foreach(var line in lines.Skip(1)){var cmd=CommandWire.Read(JsonDocument.Parse(line).RootElement.GetProperty("wire").GetString()!);var r=GameEngine.Apply(s,cmd);if(!r.Success)throw new Exception("replay rejected");s=r.NewState;prefix.Add(CommandWire.Write(cmd));if(s.Player(spec.Item2).UnitsOnBoard.Count==0)break;}
 var stalled=Snap(s);var legalByPlayer=new List<object>();var t=s;for(int i=0;i<2;i++){legalByPlayer.Add(new{seat=(int)t.ActivePlayer,commands=LegalMoves.For(t).GroupBy(c=>c.GetType().Name).ToDictionary(g=>g.Key,g=>g.Count())});t=GameEngine.Apply(t,new EndTurn(t.ActivePlayer)).NewState;}
 var recovery=new List<object>();while(!s.IsGameOver&&recovery.Count<300){var c=Choose(s,false);var rr=GameEngine.Apply(s,c);if(!rr.Success)throw new Exception("continuation rejected");s=rr.NewState;recovery.Add(new{wire=CommandWire.Write(c),state=Snap(s)});}
 notes.Add(new{kind="counterplay-stock-redeploy-k3",source=spec.Item1,setup=setup.ToWire(),prefix,stalled,legalByPlayer,recovery,final=Snap(s),units=s.Players.SelectMany(p=>p.UnitsOnBoard).Select(u=>new{u.Id,u.Owner,cell=u.Cell.ToString(),u.CurrentHp,name=u.DisplayName,u.Stats.Movement,u.Stats.Range})});
 File.WriteAllText(Path.Combine(Root,"minimal-stall-"+spec.Item1.Replace(".jsonl",".txt")),"GameSetup: "+setup.ToWire()+"\n"+string.Join("\n",prefix)+"\n# Banked player now has no units but an affordable template; refusing deployment until round100 forces draw.\n");
 }
 int checkedGames=0;foreach(var file in Directory.GetFiles(Root,"*.jsonl")){var ll=File.ReadAllLines(file);var gs=GameFactory.Build(GameSetup.Parse(JsonDocument.Parse(ll[0]).RootElement.GetProperty("setup").GetString()!));foreach(var line in ll.Skip(1)){var c=CommandWire.Read(JsonDocument.Parse(line).RootElement.GetProperty("wire").GetString()!);var rr=GameEngine.Apply(gs,c);if(!rr.Success)throw new Exception(file+" failed "+c);gs=rr.NewState;}if(!gs.IsGameOver)throw new Exception(file+" not finished");checkedGames++;if(file.EndsWith("k3-seed7-bank-1.jsonl"))notes.Add(new{kind="baseline-draw-inspection",source=file,final=Snap(gs),units=gs.Players.SelectMany(p=>p.UnitsOnBoard).Select(u=>new{u.Id,u.Owner,cell=u.Cell.ToString(),u.CurrentHp,name=u.DisplayName,u.Stats.Movement,u.Stats.Range})});}
 File.WriteAllText(Path.Combine(Root,"counterplay-results.json"),JsonSerializer.Serialize(notes,new JsonSerializerOptions{WriteIndented=true}));
 Console.WriteLine(JsonSerializer.Serialize(new{replayedCompleteGames=checkedGames,probes=notes.Count}));
}
}
